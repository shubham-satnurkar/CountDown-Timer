import React, { Component } from 'react'

export default class Buttons extends Component {
  
  render() {
    return (
      <div>
        <button onClick={this.props.start}>Start</button>
        <button style={{margin:10}} onClick={this.props.toggleCountDown}>Pause/Resume</button>
        <button onClick={this.props.reset}>Reset</button>
      </div>
    )
  }
}
