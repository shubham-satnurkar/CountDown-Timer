
import './App.css';
// import Myclass from './components/Myclass';
// import Navbar from './components/Navbar';

import Timerapp from './components/Timerapp';
// import TimerCount from './components/TimerCount';

function App() {
  
  return (
    <div className="App">
      {/* <Myclass /> */}
      {/* <Navbar title="Logo" /> */}

      <Timerapp />
      {/* <TimerCount/> */}
    </div>
  );
}

export default App;
